﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoccerClubManagement.Models
{
    public interface IPlayerRepository
    {
        IQueryable<Player> Players { get; }

        void AddPlayer(Player player);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace SoccerClubManagement.Models
{
    public class EFPlayerRepository : IPlayerRepository
    {
        ApplicationDbContext context;

        public EFPlayerRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        public IQueryable<Player> Players => context.Players
            //.Include(p => p.pList)
            ;
        public void AddPlayer(Player player)
        {
            //if (player.PlayerID == 0)
            //{
            //    context.Players.Add(player);
            //}
            //else
            //{
            //    Player dbEntry = context.Players.FirstOrDefault(p => p.PlayerID == player.PlayerID);
            //    if (dbEntry != null)
            //    {
            //        dbEntry.PlayerName = player.PlayerName;
            //        dbEntry.PlayerAge = player.PlayerAge;
            //        dbEntry.PlayerHeight = player.PlayerHeight;
            //        dbEntry.PlayerWeight = player.PlayerWeight;
            //    }
            //}
            context.Add(player);
            context.SaveChanges();
        }
    }
}

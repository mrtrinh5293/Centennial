﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoccerClubManagement.Models
{
    public class FakeClubRepository /*: IClubRepository*/
    {
        private static List<Club> clubs = new List<Club> { };

        public IQueryable<Club> Clubs => clubs.AsQueryable<Club>();


        public void SaveClub(Club clubList)
        {
            clubs.Add(clubList);

        }

        //public IQueryable<Club> Clubs { get; }

        //public static void AddResponse(Club clubList)
        //{
        //    Clubs.Add(clubList);
        //}

    }
}

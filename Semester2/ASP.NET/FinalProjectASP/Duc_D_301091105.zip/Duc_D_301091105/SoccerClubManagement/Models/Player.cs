﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoccerClubManagement.Models
{
    public class Player
    {
        //public ICollection<PlayerList> pList { get; set; }
        public int PlayerID { get; set; }
        public string PlayerName { get; set; }
        public int PlayerAge { get; set; }
        public int PlayerWeight { get; set; }
        public int PlayerHeight { get; set; }
    }

    public class getPlayer
    {
        private List<PlayerList> playerCollection = new List<PlayerList>();
        public virtual void AddPlayer(Player player)
        {
            PlayerList listPlayer = playerCollection
                .Where(p => p.Player.PlayerID == player.PlayerID)
                .FirstOrDefault();
            if (listPlayer == null)
            {
                playerCollection.Add(new PlayerList
                {
                    Player = player
                });
            }
        }
        public virtual IEnumerable<PlayerList> pList => playerCollection;
    }

    public class PlayerList
    {
        public int PlayerLineID { get; set; }
        public Player Player { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoccerClubManagement.Models
{
    public class EFClubRepository : IClubRepository
    {
        ApplicationDbContext context;

        public EFClubRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        public IQueryable<Club> Clubs => context.Clubs;
        public void SaveClub(Club club)
        {
            if (club.ClubID == 0)
            {
                context.Clubs.Add(club);
            }
            else
            {
                Club dbEntry = context.Clubs.FirstOrDefault(p => p.ClubID == club.ClubID);
                if (dbEntry != null)
                {
                    dbEntry.ClubName = club.ClubName;
                    dbEntry.ClubEmail = club.ClubEmail;
                    dbEntry.ClubPhoneNumber = club.ClubPhoneNumber;
                }
            }
            context.SaveChanges();
        }
        public Club DeleteClub(int clubID)
        {
            Club dbEntry = context.Clubs
            .FirstOrDefault(c => c.ClubID == clubID);
            if (dbEntry != null)
            {
                context.Clubs.Remove(dbEntry);
                context.SaveChanges();
            }
            return dbEntry;
        }
    }
}

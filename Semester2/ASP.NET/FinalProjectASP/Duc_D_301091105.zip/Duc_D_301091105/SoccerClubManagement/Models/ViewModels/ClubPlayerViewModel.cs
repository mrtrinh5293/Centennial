﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SoccerClubManagement.Models.ViewModels
{
    public class ClubPlayerViewModel
    {
        //public IEnumerable<Club> Clubs { get; set; }

        //public IQueryable<Club> Clubss { get; set; }
        public Player Players { get; set; }
        public Club Clubs { get; set; }

        //public string ReturnUrl { get; internal set; }
        //public IEnumerable<Player> Player { get; set; }
        //public IQueryable<Player> Players { get; set; }
    }
}

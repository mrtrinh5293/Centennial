﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SoccerClubManagement.Models;
using SoccerClubManagement.Models.ViewModels;


namespace SoccerClubManagement.Controllers
{
    public class HomeController : Controller
    {
        IClubRepository repository;
        //private Player playerRepository;
        IPlayerRepository playerRepository;

        public HomeController(IClubRepository repo, IPlayerRepository playerRepo)
        {
            repository = repo;
            playerRepository = playerRepo;
        }

        //public HomeController(IClubRepository repo)
        //{
        //    repository = repo;
        //}
        public ViewResult Index()
        {
            return View();
        }
        public ViewResult AddClubViews()
        {
            return View();
        }
        [HttpPost]
        public ViewResult AddClubViews(Club club)
        {
            repository.SaveClub(club);
            return View("ClubListViews", repository.Clubs.OrderBy(c => c.ClubName));
        }
        [HttpGet]
        public ViewResult ClubListViews()
        {
            return View(repository.Clubs.OrderBy(c => c.ClubName));
        }



        public IActionResult ClubDetailsViews(string clubName, string playerName)
        {

            //return View(repository.Clubs.Where(a => a.ClubName == clubName).First());
            return View(new ClubPlayerViewModel
            {
                Clubs = repository.Clubs.Where(c => c.ClubName == clubName).First(),
                //Players = playerRepository.Players.Where(p => p.PlayerName == playerName).First()
            });
        }

        public ViewResult UpdateViews(int clubId) =>
             View(repository.Clubs
             .FirstOrDefault(c => c.ClubID == clubId));

        [HttpPost]
        public IActionResult UpdateViews(Club club)
        {
            if (ModelState.IsValid)
            {
                repository.SaveClub(club);
                TempData["message"] = $"{club.ClubName} updated information has been saved";
                return RedirectToAction("ClubListViews");
            }
            else
            {
                // there is something wrong with the data values
                return View(club);
            }
        }

        [HttpPost]
        public IActionResult DeleteClub(int clubID)
        {
            Club deletedClub = repository.DeleteClub(clubID);
            if (deletedClub != null)
            {
                TempData["message"] = $"{deletedClub.ClubName} was deleted";
            }
            return RedirectToAction("ClubListViews");
        }
    }
}

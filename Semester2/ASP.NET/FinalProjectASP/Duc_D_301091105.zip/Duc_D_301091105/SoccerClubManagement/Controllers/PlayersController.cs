﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SoccerClubManagement.Models;
using SoccerClubManagement.Models.ViewModels;

namespace SoccerClubManagement.Controllers
{
    public class PlayersController : Controller
    {
        IPlayerRepository playerRepository;
        IClubRepository clubRepository;
        //private Club club;
        //private Player player;
        public PlayersController(IPlayerRepository playerRepo, IClubRepository clubRepo)
        //public PlayersController(IPlayerRepository repo, Player playerManager)

        {
            playerRepository = playerRepo;
            clubRepository = clubRepo;
            //player = playerManager;
        }
        [HttpGet]
        public ViewResult PlayerListTest()
        {
            return View("PlayerListTest", playerRepository.Players.OrderBy(c => c.PlayerName));

            //return View(new ClubPlayerViewModel
            //{
            //    Players = playerRepository.Players.OrderBy(c => c.PlayerName)
            //});

        }


        public ViewResult PlayerManagement()
        {
            return View();
        }
        [HttpPost]
        // ADD PLAYER WORKING BUT IS NOT WITHIN CLUB--------------
        //public ViewResult AddPlayerViews(Player player)
        //{
        //    playerRepository.AddPlayer(player);
        //    return View("PlayerListTest", repository.Players.OrderBy(c => c.PlayerName));
        //}

            // --- WITHIN CLUB -----
        public ViewResult PlayerManagement(ClubPlayerViewModel playerModel)
        {
            //repository.AddPlayer(player);
            //return View("PlayerListTest", repository.Players.OrderBy(c => c.PlayerName));
            Club club = clubRepository.Clubs.FirstOrDefault(c => c.ClubID == playerModel.Players.PlayerID);
            playerRepository.AddPlayer(playerModel.Players);
            return View();
        }

        //public ViewResult PlayerListTest(string returnUrl)
        //{
        //    return View(new ClubPlayerDetailViews
        //    {
        //         = cart,
        //        ReturnUrl = returnUrl
        //    });
        //}
        //public RedirectToActionResult AddPlayerToList(int playerID, string returnUrl)
        //{
        //    Player player = repository.Players
        //        .FirstOrDefault(p => p.PlayerID == playerID);
        //    if(player != null)
        //    {

        //    }
        //}
    }
}
//~/Views/Players/PlayerListTest.cshtml